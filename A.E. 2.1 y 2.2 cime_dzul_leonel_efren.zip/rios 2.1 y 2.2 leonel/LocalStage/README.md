# JavaScript-Crud-Operation
Form Submission Using JavaScript, CSS &amp; Html

Output Screens

![jsCapture](https://user-images.githubusercontent.com/66914300/131905548-df5878da-4dc5-4f24-bf49-89d3399170a1.JPG)


![Screenshot (169)](https://user-images.githubusercontent.com/66914300/131905557-ec99cc31-20df-4704-b36f-3e44e9842a3b.png)

