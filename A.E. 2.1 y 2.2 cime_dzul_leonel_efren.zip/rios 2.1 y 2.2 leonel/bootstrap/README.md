<h1>Carpeta con todo el código trabajado en el video - Parte IV.</h1>
<h2>Creada por medio del Framework Bootstrap</h2>
<br>
<h2>Al descargar este proyecto, debes efectuar los siguientes pasos:</h2>
<ol>
  <li>Descomprimir la carpeta</li>
  <li>Abrir en Visual Studio Code la carpeta del proyecto</li>
</ol>

Listo ya tienes la carpeta con todo el código para que puedas seguir el vídeo de una forma mas facil.
<h2 style="text-align:center">Si quieres ir desde 0 a 100 en el <strong>Desarrollo Web FullStack</strong> - (Front-End y Back-End): Aquí te dejo una ruta que te prepare:</h2>
<table>
  <tr>
    <td>
      <a href="https://cedavilu.com/curso-desarrollo-web-detalle.html" target="_blank"> <img src="https://cedavilu.com/assets/img/cursos/cursos-1.png" > </a>      
    </td>
    <td>
       <a href="https://cedavilu.com/curso-javascript-detalle.html" target="_blank"><img style="width:25" src="https://cedavilu.com/assets/img/cursos/cursos-2.png" ></a>      
    </td>
    <td>
      <a href= "https://cedavilu.com/curso-javascript-avanzado-detalle.html" target="_blank"><img style="width:25" src="https://cedavilu.com/assets/img/cursos/cursos-3.png" ></a>
    </td>
    <td>
    <a href="https://cedavilu.com/curso-nodejs-detalle.html" target="_blank"> <img style="width:25" src="https://cedavilu.com/assets/img/cursos/cursos-4.png" ></a>
    </td>
  </tr>
</table>
