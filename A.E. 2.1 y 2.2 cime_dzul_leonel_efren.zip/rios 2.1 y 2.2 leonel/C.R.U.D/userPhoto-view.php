<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>



<p>ESTA PAGINA SE EJECUTA CON XAMPP CON APACHE PARA QUE SE MUESTRE BIEN</p>

<div class="container is-fluid mb-6">
    <h1 class="title">Mi foto de perfil</h1>
    <h2 class="subtitle">Actualizar foto de perfil</h2>
</div>

<div class="container pb-6 pt-6">
    <p class="has-text-right pt-4 pb-4">
        <a href="#" class="button is-link is-rounded btn-back">&lt;- Regresar atrás</a>
    </p>

    <h2 class="title has-text-centered">Nombre completo</h2>
    <p class="has-text-centered pb-6"><strong>Usuario creado:</strong> Fecha &nbsp; <strong>Usuario actualizado:</strong> Fecha</p>

    <div class="columns">
        <div class="column is-two-fifths">
            <figure class="image mb-6">
                <img class="is-rounded" src="app/views/fotos/default.png">
            </figure>
            
            <form class="FormularioAjax" action="" method="POST" autocomplete="off">
                <input type="hidden" name="modulo_usuario" value="eliminarFoto">
                <input type="hidden" name="usuario_id" value="1">
                <p class="has-text-centered">
                    <button type="submit" class="button is-danger is-rounded">Eliminar foto</button>
                </p>
            </form>

            <figure class="image mb-6">
                <img class="is-rounded" src="app/views/fotos/default.png">
            </figure>
        </div>

        <div class="column">
            <form class="mb-6 has-text-centered FormularioAjax" action="" method="POST" enctype="multipart/form-data" autocomplete="off">
                <input type="hidden" name="modulo_usuario" value="actualizarFoto">
                <input type="hidden" name="usuario_id" value="1">
                <label>Foto o imagen del usuario</label><br>
                <div class="file has-name is-boxed is-justify-content-center mb-6">
                    <label class="file-label">
                        <input class="file-input" type="file" name="usuario_foto" accept=".jpg, .png, .jpeg">
                        <span class="file-cta">
                            <span class="file-label">
                                Seleccione una foto
                            </span>
                        </span>
                        <span class="file-name">JPG, JPEG, PNG. (MAX 5MB)</span>
                    </label>
                </div>
                <p class="has-text-centered">
                    <button type="submit" class="button is-success is-rounded">Actualizar foto</button>
                </p>
            </form>
        </div>
    </div>

    <article class="message is-danger">
        <div class="message-header">
            <p>¡Ocurrió un error inesperado!</p>
        </div>
        <div class="message-body">No se pudieron cargar los datos solicitados</div>
    </article>
</div>

<script type="text/javascript">
    let btn_back = document.querySelector(".btn-back");

    btn_back.addEventListener('click', function(e){
        e.preventDefault();
        window.history.back();
    });
</script>

</body>
</html>
